export const isBoolean = value => typeof value === 'boolean';
